<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>60 Day Challenge</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="shortcut icon" href="/assets/images/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="/public/assets/plugins/fontawesome/css/all.min.css"/>
</head>

<body>

    <?php echo $__env->make('layouts.home.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main id="content">
        <div class="container mt-3 mb-5" id="jumbotron">
            <div class="row flex-column-reverse flex-md-row">
                <div class="col-lg-4 d-flex flex-column justify-content-center">
                    <h2>Contribute to Campus and Get Credit Point</h2>
                    <p class="my-1">There are many variations of passages of Lorem Ipsum available, but the majority
                        have suffered
                        alteration in some form</p>
                    <div class="d-flex position-relative mt-4">
                        <input type="text" class="form-control" placeholder="Enter your challenge..."
                            aria-label="Enter your challenge..." aria-describedby="button-addon2">
                        <button class="btn btn-primary py-2 px-4" type="button" id="button-addon2">Check</button>
                    </div>
                </div>
                <div class="col-lg-8 mb-3 mb-md-0">
                    <img src="/assets/images/banner.png" class="img-fluid" alt="">
                </div>
            </div>
        </div>

        <div id="highlight" class="py-3">
            <div class="container py-5">
                <div class="row">
                    <div class="col-lg-4 d-flex flex-column justify-content-center">
                        <h3>The most contributed Leaderboard</h3>
                        <p class="mt-2">Here are some of the most credit points recipients on campus</p>
                    </div>
                    <div class="col-lg-1"></div>
                    <div class="col-lg-6">
                        <div class="table-responsive">
                            <table class="table table-borderedless" cellspacing="500">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>Points</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Rizkan</td>
                                        <td>4000pt</td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td>Rizkan</td>
                                        <td>4000pt</td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td>Rizkan</td>
                                        <td>4000pt</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div>
        </div>

        <section id="section-one" class="py-5">
            <div class="container">
                <div class="row text-center row-title">
                    <h2>How It Works</h2>
                    <p>Here are some of the most credit points recipients on campus</p>
                </div>
                <div class="row mt-5">
                    <div class="col-lg-7 mb-3">
                        <img src="/assets/images/section-1.png" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-5 d-flex flex-column justify-content-center mb-5">
                        <h2>Statistic of Student Index Point</h2>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have
                            suffered alteration in some form</p>
                    </div>
                </div>
            </div>
        </section>

        <section id="section-two" class="py-3">
            <div class="container">
                <div class="row mt-5 flex-md-row flex-column-reverse">
                    <div class="col-lg-5 d-flex flex-column justify-content-center mb-5">
                        <h2>Statistic of Student Index Point</h2>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have
                            suffered alteration in some form</p>
                    </div>
                    <div class="col-lg-1">
                    </div>
                    <div class="col-lg-6 d-flex justify-content-end mb-3">
                        <img src="/assets/images/section-2.png" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </section>

        <section id="list" class="my-5">
            <div class="container">
                <div class="row text-center row-title">
                    <h2>List Task Available</h2>
                    <p>Some assignments or activities that can get credit points for active <br> campus students</p>
                </div>
                <div class="row" id="task-list">
                    <div class="col-lg-4 mt-4">
                        <div class="card bg-transparent">
                            <a href="#">
                                <div class="card-header p-4 bg-transparent">
                                    <h2>How to Become Programmer</h2>
                                    <div class="images my-3">
                                        <img src="/assets/images/section-1.png" alt="" class="img-fluid">
                                    </div>
                                    <p class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, nobis!
                                    </p>
                                    <div class="badge text-bg-primary">All</div>
                                </div>
                            </a>
                            <div class="card-body bg-transparent">
                                <div class="justify-content-between d-flex">
                                    <div>
                                        <span class="mx-1"><i class="fas fa-code"></i> Coding</span>
                                        <span class="mx-1"><i class="fas fa-clock"></i> 100 Hours</span>
                                    </div>
                                    <div>
                                        <span class="mx-1"><i class="fas fa-calendar-alt"></i> 60 Day</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-4">
                        <div class="card bg-transparent">
                            <a href="#">
                                <div class="card-header p-4 bg-transparent">
                                    <h2>How to Become Programmer</h2>
                                    <div class="images my-3">
                                        <img src="/assets/images/image-3.png" alt="" class="img-fluid">
                                    </div>
                                    <p class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, nobis!
                                    </p>
                                    <div class="badge text-bg-primary">All</div>
                                </div>
                            </a>
                            <div class="card-body bg-transparent">
                                <div class="justify-content-between d-flex">
                                    <div>
                                        <span class="mx-1"><i class="fas fa-code"></i> Coding</span>
                                        <span class="mx-1"><i class="fas fa-clock"></i> 100 Hours</span>
                                    </div>
                                    <div>
                                        <span class="mx-1"><i class="fas fa-calendar-alt"></i> 60 Day</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-4">
                        <div class="card bg-transparent">
                            <a href="#">
                                <div class="card-header p-4 bg-transparent">
                                    <h2>How to Become Programmer</h2>
                                    <div class="images my-3">
                                        <img src="/assets/images/section-2.png" alt="" class="img-fluid">
                                    </div>
                                    <p class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, nobis!
                                    </p>
                                    <div class="badge text-bg-primary">All</div>
                                </div>
                            </a>
                            <div class="card-body bg-transparent">
                                <div class="justify-content-between d-flex">
                                    <div>
                                        <span class="mx-1"><i class="fas fa-code"></i> Coding</span>
                                        <span class="mx-1"><i class="fas fa-clock"></i> 100 Hours</span>
                                    </div>
                                    <div>
                                        <span class="mx-1"><i class="fas fa-calendar-alt"></i> 60 Day</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <div id="for-questions" class="my-5">
            <div class="container">
                <div class="row text-center row-title">
                    <h2>Frequently Asked Questions</h2>
                    <p>Audience questions that can be asked on our platform</p>
                </div>
                <div class="row justify-content-center mt-4">
                    <div class="accordion col-lg-10" id="questions">
                        <div class="accordion-item mb-3">
                            <h2 class="accordion-header" id="question-1">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Accordion Item #1
                                </button>
                            </h2>
                            <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="question-1"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>This is the first item's accordion body.</strong> It is shown by default,
                                    until the collapse plugin adds the appropriate classes that we use to style each
                                    element. These classes control the overall appearance, as well as the showing and
                                    hiding via CSS transitions. You can modify any of this with custom CSS or overriding
                                    our default variables. It's also worth noting that just about any HTML can go within
                                    the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item mb-3">
                            <h2 class="accordion-header" id="question-2">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Accordion Item #2
                                </button>
                            </h2>
                            <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="question-2"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>This is the second item's accordion body.</strong> It is hidden by default,
                                    until the collapse plugin adds the appropriate classes that we use to style each
                                    element. These classes control the overall appearance, as well as the showing and
                                    hiding via CSS transitions. You can modify any of this with custom CSS or overriding
                                    our default variables. It's also worth noting that just about any HTML can go within
                                    the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                        <div class="accordion-item mb-3">
                            <h2 class="accordion-header" id="question-3">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Accordion Item #3
                                </button>
                            </h2>
                            <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="question-3"
                                data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>This is the third item's accordion body.</strong> It is hidden by default,
                                    until the collapse plugin adds the appropriate classes that we use to style each
                                    element. These classes control the overall appearance, as well as the showing and
                                    hiding via CSS transitions. You can modify any of this with custom CSS or overriding
                                    our default variables. It's also worth noting that just about any HTML can go within
                                    the <code>.accordion-body</code>, though the transition does limit overflow.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>

    <?php echo $__env->make('layouts.home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="/assets/plugins/bootstrap/js/bootstrap.bundle.min.js">
    </script>
</body>

</html>
<?php /**PATH /home/rizkan/Applications/Web/60daychallenge/be/resources/views/contents/pages/home.blade.php ENDPATH**/ ?>